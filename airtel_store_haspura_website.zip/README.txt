Airtel Store Haspura website

Files:
- index.html: complete responsive one-page website.

Before publishing:
1. Confirm the exact shop address, PIN code and opening hours.
2. Verify that you are authorized to use any official Airtel branding or claims.
3. Keep control of your domain and hosting accounts by registering them in your own name/email and enabling two-factor authentication.

To publish for free, you can use a hosting provider such as GitHub Pages or Netlify. A custom domain usually costs extra. The HTML file can also be opened locally in a browser to preview it.
